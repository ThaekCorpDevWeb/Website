package net.minecraft.launcher;

import java.net.URI;
import java.net.URISyntaxException;

public class LauncherConstants {
    public static final String VERSION_NAME = "1.0"; //Version du Launcher
    public static final int VERSION_NUMERIC = 7;
    public static final String DEFAULT_PROFILE_NAME = "MON_NOM_DE_PROFIL"; //Nom de Profil par Defaut.
    public static final String SERVER_NAME = "MON_NOM_DE_SERVEUR"; //Nom de votre Serveur.
    public static final URI URL_REGISTER = constantURI("https://account.mojang.com/register"); //Lien g�r� par le bouton Register dans le Launcher.
    // public static final String URL_DOWNLOAD_BASE =
    // "https://s3.amazonaws.com/Minecraft.Download/";
    public static final String URL_DOWNLOAD_BASE = "http://monsite.com/launcher/"; //Dossier principal de votre launcher sur votre serveur FTP.
    public static final boolean useModResource = false; //Si vous utilisez des mods h�berg�s sur FTP, mettez sur true. Sinon mettez false.
    public static final String URL_DOWNLOAD_MODS = "http://monsite.com/ressources/"; //Dossier principal de vos ressouces perso sur votre serveur FTP.
    public static final String URL_RESOURCE_BASE = "http://resources.download.minecraft.net/"; //Dossier principal des ressources officielles du jeu. (par defaut "https://s3.amazonaws.com/Minecraft.Resources/" ou "http://resources.download.minecraft.net/")
    public static final String LIBRARY_DOWNLOAD_BASE = "https://libraries.minecraft.net/"; //Dossier principal des librairies utilis�es par le jeu. (par defaut https://libraries.minecraft.net/ ou "https://s3.amazonaws.com/Minecraft.Download/libraries/")
    public static final String URL_BLOG = "http://mcupdate.tumblr.com"; //Blog affich� dans le launcher au d�marrage. (par defaut "http://mcupdate.tumblr.com")
    public static final String URL_STATUS_CHECKER = "http://status.mojang.com/check"; //Lien de V�rification de Compte chez MOJANG. ("http://status.mojang.com/check")
    public static final String URL_BOOTSTRAP_DOWNLOAD = "http://monsite.com/launcher/bootstrap.jar"; //Adresse de votre fichier bootstrap.jar sur votre serveur FTP.
    public static final URI URL_FORGOT_USERNAME = constantURI("http://help.mojang.com/customer/portal/articles/1233873"); //Lien URL de "Pseudo oubli� ?". ("http://help.mojang.com/customer/portal/articles/1233873")
    public static final URI URL_FORGOT_PASSWORD_MINECRAFT = constantURI("http://help.mojang.com/customer/portal/articles/329524-change-or-forgot-password"); //Lien URL de "Mot de passe oubli� ?". ("http://help.mojang.com/customer/portal/articles/329524-change-or-forgot-password")
    public static final URI URL_FORGOT_MIGRATED_EMAIL = constantURI("http://help.mojang.com/customer/portal/articles/1205055-minecraft-launcher-error---migrated-account"); //Lien URL de Migration Mail. ("http://help.mojang.com/customer/portal/articles/1205055-minecraft-launcher-error---migrated-account")
	public static final String URL_AUTHENTICATION_SERVER = "https://authserver.mojang.com/"; //Serveur d'authentification, par defaut : "https://authserver.mojang.com/"
	
    public static URI constantURI(final String input) {
        try {
            return new URI(input);
        }
        catch(final URISyntaxException e) {
            throw new Error(e);
        }
    }
}